from pyspark import pipelines as dp
from pyspark.sql.functions import *

#----------------customers---------------------------------
@dp.temporary_view
def stg_dim_customers():
    df = spark.readStream.table("gold_obt")
    
    
    df = df.select(
    "customer_id",
    "customer_email",
    "customer_phone",
    "customer_city",
    "customers_updated_datetime"
)
    return df

    #----------------drivers---------------------------------

@dp.temporary_view
def stg_dim_drivers():
    df = spark.readStream.table("gold_obt")
    
    
    df = df.select(
    "driver_id",
    "driver_name",
    "driver_city",
    "drivers_updated_datetime"
)
    return df


    #----------------vehicles---------------------------------
@dp.temporary_view
def stg_dim_vehicles():
    df = spark.readStream.table("gold_obt")
    
    
    df = df.select(
    "vehicle_id",
    "vehicle_model",
    "vehicle_year",
    "vehicles_updated_datetime"
)
    return df

    #----------------payments---------------------------------

@dp.temporary_view
def stg_dim_payments():
    df = spark.readStream.table("gold_obt")
    
    
    df = df.select(
    "payment_id",
    "payment_status",
    "payment_method",
    "payment_amount",
    "payments_updated_datetime"
)
    return df
    #----------------trips---------------------------------

@dp.temporary_view
def stg_dim_trips():
    df = spark.readStream.table("gold_obt")
    
    
    df = df.select(
    "trip_id",
    "trip_start_ts",
    "trip_end_ts",
    "trip_start_location",
    "trip_end_location",
    "trip_status",
    "updated_datetime"
)
    return df

