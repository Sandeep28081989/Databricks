from pyspark import pipelines as dp
from pyspark.sql.functions import *

@dp.table
def bronze_trips():

    df = spark.readStream.format("cloudFiles") \
        .option("cloudFiles.format", "csv") \
            .option("cloudfiles.inferColumntypes","true")\
            .load("abfss://raw@azurestoragehome.dfs.core.windows.net/rideshare/trips")  
    return df
    