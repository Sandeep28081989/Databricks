# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS azuredatabricks.ldp_medallion

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE azuredatabricks.ldp_medallion.trips

# COMMAND ----------

folders = dbutils.fs.ls("abfss://raw@azurestoragehome.dfs.core.windows.net/rideshare")

for data_folder in folders:
    df = spark.read.format("csv")\
    .option("header", "true")\
        .option("inferSchema", "true")\
            .load(data_folder.path)
    df = df.withColumnRenamed("updated_datetime",f"{data_folder.name.replace("/","")}_updated_datetime")
    

    if data_folder.name != 'trips/':
        df.write.format('delta')\
        .mode('overwrite')\
        .option("overwriteschema","true")\
        .saveAsTable(f"azuredatabricks.ldp_medallion.{data_folder.name.replace("/","")}")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from azuredatabricks.ldp_medallion.customers

# COMMAND ----------

dbutils.fs.help()

# COMMAND ----------

dbutils.fs.ls("abfss://raw@azurestoragehome.dfs.core.windows.net/rideshare")