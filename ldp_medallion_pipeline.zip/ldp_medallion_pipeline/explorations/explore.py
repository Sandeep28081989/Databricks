# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "6"
# ///
# MAGIC %sql
# MAGIC select * from azuredatabricks.ldp_medallion.bronze_trips

# COMMAND ----------

# MAGIC %sql
# MAGIC Select * from azuredatabricks.ldp_medallion.silver_trips

# COMMAND ----------

# MAGIC %sql
# MAGIC Select * from azuredatabricks.ldp_medallion.gold_obt

# COMMAND ----------

# MAGIC %sql
# MAGIC Select * from azuredatabricks.ldp_medallion.dim_customers
# MAGIC where customer_id = 2

# COMMAND ----------

# MAGIC %sql
# MAGIC Select * from azuredatabricks.ldp_medallion.fact

# COMMAND ----------

# MAGIC %sql
# MAGIC update azuredatabricks.ldp_medallion.customers
# MAGIC set customer_name = "xyz",
# MAGIC   customers_updated_datetime = current_timestamp
# MAGIC where customer_id = 2

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from azuredatabricks.ldp_medallion.customers
# MAGIC where customer_id = 2
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from azuredatabricks.ldp_medallion.fact